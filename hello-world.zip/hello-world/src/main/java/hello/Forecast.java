package hello;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


 /**
  * Forcast class
  * @author mptapang
  *
  */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Forecast {

	
	/* Weather Object */
	private Weather[] weather;
	/* Temperature object */
	private Temperature main;
	/* Coordinates object */
	private Coord coord;
	/* ID */
	private String id;
	/* name */
	private String name;
	/* message */
	private String message;
	/* code */
	private int cod;
	
	
	/**
	 * Constructor for class Forecast
	 */
	public Forecast() {
		
	}
	
	/**
	 * Set the code and message for Forecast object
	 * @param cod
	 * @param message
	 */
	public Forecast(int cod,String message) {
		this.message = message;
		this.cod = cod;
		
	}
	
	
	/**
	 * Method for setting the name	
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Method for getting the name
	 * @return name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Method for getting the message
	 * @return message
	 */
	public String getMessage() {
		return this.message;
	}
	
	/**
	 * Method for setting the message
	 * @param msg
	 */
	public void setMessage(String msg) {
		this.message = msg;
	}
	
	/**
	 * method for getting the code
	 * @return code
	 */
	public int getCod() {
		return this.cod;
	}
	
	/**
	 * Method to return the actual weather
	 * @return actual weather
	 */
	public Weather[] getWeather() {
		return this.weather;
	}
	
	/**
	 * method of setting the actual weather
	 * @param weather
	 */
	public void setWeather(Weather[] weather) {
		this.weather = weather;
	}
	
	/**
	 * Method to return the temperature
	 * @return temperature
	 */
	public Temperature getMain() {
		return this.main;
	}
	
	/**
	 * Method of setting the temperature
	 * @param temp
	 */
	public void setMain(Temperature temp) {
		this.main = temp;
	}
	
	/**
	 * Method to return the location
	 * @return location
	 */
	public Coord getCoord() {
		return this.coord;
	}
	
	
	/**
	 * method of getting the ID
	 * @return id
	 */
	public String getId() {
		return this.id;
	}
	
	/**
	 * method of setting the id
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	
	
}
