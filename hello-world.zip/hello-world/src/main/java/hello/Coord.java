package hello;

/**
 * 
 * @author mptapang
 *
 */
public class Coord {
	/* longitude */
	private String lon;
	/* Latitude */
	private String lat;

	/**
	 * Constructor for class Coord
	 */
	public Coord() {

	}

	/**
	 * Method for getting the longitude
	 * @return longitude
	 */
	public String getLon() {
		return this.lon;
	}

	/**
	 * Method for getiing the latitude
	 * @return latitude
	 */
	public String getLat() {
		return this.lat;
	}
}
