package hello;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import hello.MainController;

@RestController
public class GreetingController {

	private String aweather;
	private String loc;
	private String resid;
	private String temp;

	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@RequestMapping("/weather")
	public Forecast WeatherController(@RequestParam(value = "cityname", defaultValue = "Manila") String name,
			RestTemplate restTemplate) {
		Forecast quote = new Forecast();

		try {

			quote = restTemplate.getForObject("http://api.openweathermap.org/data/2.5/weather?q=" + name
					+ "&APPID=6324f65bf8278689b2298886ddea3f55", Forecast.class);

			MainController dbData = new MainController();
			Weather[] weather = quote.getWeather();

			aweather = weather[0].getDescription();
			loc = quote.getCoord().getLat();
			resid = quote.getId();
			Temperature m = quote.getMain();
			temp = m.getTemp();

			dbData.addNewLog(aweather, loc, resid, temp);
		} catch (Exception e) {
			quote.setMessage(e.getMessage());

		}
		return quote;
	}

}
