package hello;

/**
 * 
 * @author mptapang
 *
 */
public class Temperature {
	
	private String temp;
	private int humidity;
	private String temp_min;
	private String temp_max;

	public Temperature() {

	}

	public String getTemp() {
		return this.temp;
	}

	public int getHumidity() {
		return this.humidity;
	}

	public String getTemp_max() {
		return this.temp_max;
	}

	public String getTemp_min() {
		return this.temp_min;
	}
}
