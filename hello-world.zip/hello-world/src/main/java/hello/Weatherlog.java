package hello;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Weatherlog {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer Id;
	private String responseid;
	private String location;
	private String ActualWeather;
	private String temperature;
	private String timestamp;

	public long getId() {
		return this.Id;
	}

	public void setId(int id) {
		this.Id = id;
	}

	public String getResponseid() {
		return this.responseid;
	}

	public void setResponseid(String resid) {
		this.responseid = resid;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String loc) {
		this.location = loc;
	}

	public String getActualWeather() {
		return this.ActualWeather;
	}

	public void setActualWeather(String aweather) {
		this.ActualWeather = aweather;
	}

	public String getTemperature() {
		return this.temperature;
	}

	public void setTemperature(String temp) {
		this.temperature = temp;
	}

	public String getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(String tstamp) {
		this.timestamp = tstamp;
	}
}
